
sh experiment/bn_mean_std_updating_exp/eps16_pgd20/Trades_AT.sh

sh experiment/bn_mean_std_updating_exp/eps16_pgd20/Trades_CAT.sh



